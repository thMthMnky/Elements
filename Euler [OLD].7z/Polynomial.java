
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package MyMath;
/**
 *
 * @author Riemann
 */
public class Polynomial {

    /**
     *
     */
    
    private int n ;     // degree of polynomial (-infinity for the zero polynomial)
    private double[] Coef;  // coefficients
 
    
//class constructors
    public Polynomial ()
    {
        Coef = null;
        n = -infinity;
    }
    /**
     *
     * @param degree
     */
    public Polynomial(int degree)
    {
       n = degree+1;
       Coef = new double[n];
    }
    
    /**
     *
     * @param coefficients
     */
    public Polynomial(double[] coefficients)
    {
        
        Coef = coefficients;
        n = coefficients.length;
    }        
 
    /**
     *
     * @return
     */
    @SuppressWarnings("ReturnOfCollectionOrArrayField")
    public double[] getCoef(){
        return this.Coef;
        
    }

    @SuppressWarnings("AssignmentToCollectionOrArrayFieldFromParameter")
    private void setCoef(double[] Coef) {
        this.Coef = Coef;
        this.setN(Coef.length);
    }
    
    private int getN() {
        return n;
    }
    
    private void setN(int m){
        this.n = m;
    }
       
    // return the degree of this polynomial (infinity for the zero polynomial)

    /**
     *
     * @return
     */
    public int degree() {
        return this.n-1;
  
    }

    /**
     *
     * @param indexofcoefficient
     * @return
     */
    public double atCoef(int indexofcoefficient){
        double x = this.Coef[indexofcoefficient];
        return x;
    }
   

    // return f = g + h

    /**
     *
     * @param h
     * @return
     */
    public Polynomial plus(Polynomial h) {
      Polynomial f = new Polynomial();
      double[] c = new double[Math.max(this.n, h.getN())];
     
        for(int i = 0; i < Math.min(this.n, h.getN()); i++){
            c[i] = this.atCoef(i) + h.atCoef(i);
              
            if(Math.min(this.n, h.getN()) == this.n ){
                c[Math.max(this.n, h.getN())-i]=h.atCoef(Math.max(this.n, h.getN())-i);
            }else{ 
                c[Math.max(this.n, h.getN())-i]=this.atCoef(Math.max(this.n, h.getN())-i);
            }
        }
         
        f.setCoef(c);
        return f;
      } 

    // return (g - h)

    /**
     *
     * @param h
     * @return
     */
    public Polynomial minus(Polynomial h) {

        double[] c;
        c = new double[Math.max(this.n, h.getN())];
     
        for(int i = 0; i < Math.min(this.n, h.getN()); i++){
            c[i] = this.atCoef(i) - h.atCoef(i);
              
            if(Math.min(this.n, h.getN()) == this.n ){
                c[Math.max(this.n, h.getN())-i]=-h.atCoef(Math.max(this.n, h.getN())-i);
            }else{ 
                c[Math.max(this.n, h.getN())-i]=-this.atCoef(Math.max(this.n, h.getN())-i);
            }
        }
        
        Polynomial f = new Polynomial();
        f.setCoef(c);
        return f;
    }

    // return (g * h)
    /**
     *
     * @param h
     * @return
     */
    public Polynomial times(Polynomial h) {
        double[] c = null;
        c[0] = (this.atCoef(0))*(h.atCoef(0));
         
        for(int i=0; i <= this.getN() + h.getN();i++)
        {
            for(int j=0; j <= i; j++ ) {
                c[i] =+ this.atCoef(j)*h.atCoef(i-j);
            }
        } 
        Polynomial f = new Polynomial();
        f.setCoef(c);
        return f;
    }
    
    //euclidean algorithm
    //public Polynomial
    
    /**
     *
     * @param x
     * @return
     */
    public double evaluate(double x) {
        double evaluation=0;
        
        /* not to sure what the computational complexity of this snippet is but imagine
        it is larger then  the snippet right after on account of it being larger.
        
            switch( (int)Math.signum(x)){
            case -1:    for (int i = this.n; i>=0; i-- ) evaluation -= Math.pow(x, i);
            case 0:     evaluation = 0 ;
            case 1:    for (int i = this.n; i>=0; i-- ) evaluation += Math.pow(x, i);
        }
        */
        
        for(int i = this.n; i >= 0; i-- ) {evaluation = evaluation*x+ this.Coef[i];}
        return evaluation;
    }



    
}