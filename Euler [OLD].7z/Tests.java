

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import MyMath.*;
/**
 *
 * @author Riemann
 */
public class Tests {

    
    public static void main(String[] args) {
  
        double[] a = new double[5];
        for(int i =0; i<5; i++){
           a[i] = (i+2)*5;
        }
        Polynomial f = new Polynomial(a);
       
       System.out.print("The value is" + f.evaluate(3));
    }
    
    
}
