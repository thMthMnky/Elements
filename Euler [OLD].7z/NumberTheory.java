/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package MyMath;

import java.util.ArrayList;
import javax.swing.JOptionPane;


/**
 *
 * @author Riemann
 */
public class NumberTheory 
{

    /**
     * @param args the command line arguments
     */
    private static boolean isInteger(double x) 
    {
        boolean i = true;
        if (x != Math.floor(x)) 
        {
            i=false;
        } 
        
        return i;
    }

    public static boolean isEven(double x) 
    {
        boolean e = true;
        if (x % 2 != 0) 
        {
            e = false;
        } 
        
        return e;
    }

    public static boolean isOdd(double x) 
    {
        boolean o = true;
        if (x % 2 != 1) 
        {
            o = false;
        } 
        
        return o;
    }
    
    public static int[] divisors(double x){
        int[] d = null;
        int i =0 ;
        
        for(int k = 1; k <= Math.ceil(x); k++ ){
            if( x%k == 0){
                d[i] = k;
                i++;
                
            }
        }
        
        return d;
    }
       
    public static boolean isPrime(double x) 
    {
        boolean p = false;
        if(divisors(x).length == 2){
            p = true;
        }
     return p;   
    }

     //This method will produce a list of primes less than x//
    public static ArrayList<Integer> ListofPrimes(double x) 
    {
        ArrayList<Integer> PrimesUnderX = new ArrayList<>();

        PrimesUnderX.add(2);
        for (int i = 3; i <= Math.floor(x); i++) 
        {
            if (isPrime(i)) 
            {
                PrimesUnderX.add(i);

            }
        }
        return PrimesUnderX;
    }

    //This method will return the number of primes less than X//
    public static int pi(double y) 
    {
        int x = ListofPrimes(y).size();
        return x;
    }

    // This Method will compute the prime factorization of an integer. It willl be returned as 2, //
    public static int[][] Pfactor(int n) 
    {

        ArrayList<Integer> primefactors = new ArrayList<>();
        ArrayList<Integer> exponent = new ArrayList<>();
        ArrayList<Integer> List = ListofPrimes(n);


        for (int i = 0; i < List.size(); i++) 
        {

            if (n % List.get(i) == 0) 
            {
                primefactors.add(List.get(i));
            }
        }

        for (int j = 0; j < primefactors.size(); j++) 
        {
            double factor = (double) n;
            int power = 1;
            while (isInteger(factor)) 
            {
                factor = factor / primefactors.get(j);
                if (isInteger(factor)) 
                {
                    power++;
                }
            }
            exponent.add(power);
        }

        int[] exp = new int[primefactors.size()], pf = new int[primefactors.size()];

        for (int i = 0; i < primefactors.size(); i++) 
        {
            pf[i] = primefactors.get(i);
            exp[i] = exponent.get(i);
        }

        int[][] factoredINT = {exp, pf};

        return factoredINT;
    }

    public static int gcf(int n, int m) 
    {
        int gcf = 1, nLength = 0, mLength = 0;
        ArrayList<Integer> commonprimes = new ArrayList<>();
        
        
        if ((n == 0) || (m == 0)) 
        {
            gcf = Math.max(n, m);
        } 
        else if ((n == 1) || (m == 1)) 
        {
             gcf = Math.min(n, m);
        }
        int[][] x = Pfactor(n), y = Pfactor(m);

        nLength = x[1].length;
        mLength = y[1].length;

        if (nLength < mLength) 
        {
            for (int i = 0; i < nLength; i++) 
            {
                for (int j = 0; j < mLength; j++) 
                {
                    if (x[1][i] == y[1][j]) 
                    {
                        commonprimes.add(x[1][i]);
                    }
                }
            }
        } 
        else if (mLength < nLength) 
        {
            for (int i = 0; i < mLength; i++) 
            {
                for (int j = 0; j < nLength; j++) 
                {
                    if (y[1][i] == x[1][j]) 
                    {
                        commonprimes.add(y[1][i]);
                    }
                }
            }
        } 
        else if (nLength == mLength) 
        {
            for (int i = 0; i < nLength; i++) 
            {
                if (x[1][i] == y[1][i]) 
                {
                    commonprimes.add(x[1][i]);
                }
            }
        }
        for (int i = 0; i<= commonprimes.size() ; i++) 
        {
            gcf = gcf * commonprimes.get(i);
        }

        return gcf;
    }
    
    
    public static int phi(int n) 
    {
        ArrayList<Integer> ListofRELprimes = new ArrayList<>();
        for (int i = 0; i < n; i++) 
        {
            if (gcf(n, i) == 1) 
            {
                ListofRELprimes.add(i);
            }
        }
        return ListofRELprimes.size();
    }



}
