package MyMath;

/**
 *
 * @author Riemann
 */
 
public class Nat {
  private Nat succ;
  public Nat(){ 
    this.succ=new Nat();
  }
  public Nat succ(){
        return this.succ;
  }
  
}